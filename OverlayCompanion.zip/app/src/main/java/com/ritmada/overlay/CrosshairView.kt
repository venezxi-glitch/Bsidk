package com.ritmada.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import kotlin.math.min

/** Draws a crosshair and an optional ring at the exact center of the screen. Never touchable. */
class CrosshairView(context: Context, private val prefs: Prefs) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    override fun onDraw(canvas: Canvas) {
        val d = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f

        paint.color = Prefs.COLORS[prefs.colorIndex.coerceIn(0, Prefs.COLORS.lastIndex)]
        paint.alpha = prefs.opacity.coerceIn(0, 100) * 255 / 100
        paint.strokeWidth = prefs.thickness * d

        if (prefs.crosshairOn) {
            val gap = prefs.gap * d
            val len = prefs.size * d
            canvas.drawLine(cx - gap - len, cy, cx - gap, cy, paint)
            canvas.drawLine(cx + gap, cy, cx + gap + len, cy, paint)
            canvas.drawLine(cx, cy - gap - len, cx, cy - gap, paint)
            canvas.drawLine(cx, cy + gap, cx, cy + gap + len, paint)
        }
        if (prefs.ringOn) {
            canvas.drawCircle(cx, cy, prefs.ringRadiusPct / 100f * min(width, height), paint)
        }
    }
}
