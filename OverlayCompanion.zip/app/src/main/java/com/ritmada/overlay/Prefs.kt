package com.ritmada.overlay

import android.content.Context
import android.graphics.Color

class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("overlay_prefs", Context.MODE_PRIVATE)

    private fun int(key: String, def: Int) = sp.getInt(key, def)
    private fun putInt(key: String, v: Int) = sp.edit().putInt(key, v).apply()
    private fun bool(key: String, def: Boolean) = sp.getBoolean(key, def)
    private fun putBool(key: String, v: Boolean) = sp.edit().putBoolean(key, v).apply()

    var crosshairOn: Boolean
        get() = bool("ch_on", true)
        set(v) = putBool("ch_on", v)
    var size: Int // arm length, dp
        get() = int("ch_size", 12)
        set(v) = putInt("ch_size", v)
    var thickness: Int // dp
        get() = int("ch_thick", 2)
        set(v) = putInt("ch_thick", v)
    var gap: Int // dp from center
        get() = int("ch_gap", 4)
        set(v) = putInt("ch_gap", v)
    var opacity: Int // percent
        get() = int("ch_opacity", 90)
        set(v) = putInt("ch_opacity", v)
    var colorIndex: Int
        get() = int("ch_color", 2)
        set(v) = putInt("ch_color", v)
    var ringOn: Boolean
        get() = bool("ring_on", false)
        set(v) = putBool("ring_on", v)
    var ringRadiusPct: Int // percent of the screen's short side
        get() = int("ring_pct", 25)
        set(v) = putInt("ring_pct", v)
    var menuX: Int // -1 = unset
        get() = int("menu_x", -1)
        set(v) = putInt("menu_x", v)
    var menuY: Int
        get() = int("menu_y", -1)
        set(v) = putInt("menu_y", v)

    // Resets visual settings only; keeps the menu position.
    fun resetVisuals() {
        sp.edit()
            .remove("ch_on").remove("ch_size").remove("ch_thick").remove("ch_gap")
            .remove("ch_opacity").remove("ch_color").remove("ring_on").remove("ring_pct")
            .apply()
    }

    companion object {
        val COLORS = intArrayOf(
            Color.WHITE, Color.RED, Color.GREEN, Color.CYAN, Color.YELLOW, Color.MAGENTA
        )
        val COLOR_NAMES = arrayOf("White", "Red", "Green", "Cyan", "Yellow", "Magenta")
    }
}
