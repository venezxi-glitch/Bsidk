package com.ritmada.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.WindowManager.LayoutParams
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import kotlin.math.hypot
import kotlin.math.max

class OverlayService : Service() {

    companion object {
        @Volatile
        var running = false
        private const val CHANNEL_ID = "overlay"
    }

    private val wm by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }
    private val prefs by lazy { Prefs(this) }

    private var crosshair: CrosshairView? = null
    private var menuRoot: LinearLayout? = null
    private lateinit var menuParams: LayoutParams
    private lateinit var bubble: TextView
    private lateinit var panel: LinearLayout
    private var panelOpen = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_NOT_STICKY

    override fun onCreate() {
        super.onCreate()
        startInForeground() // must happen first, or startForegroundService() crashes the app
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        try {
            addCrosshair()
            addMenu()
            running = true
        } catch (e: Exception) {
            removeViews()
            stopSelf()
        }
    }

    override fun onDestroy() {
        running = false
        removeViews()
        super.onDestroy()
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Overlay running")
            .setContentText("Tap the floating button to open the menu")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
        startForeground(1, n)
    }

    private fun removeViews() {
        crosshair?.let { v -> runCatching { wm.removeView(v) } }
        crosshair = null
        menuRoot?.let { v -> runCatching { wm.removeView(v) } }
        menuRoot = null
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun screenSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            resources.displayMetrics.let { it.widthPixels to it.heightPixels }
        }

    private fun redraw() {
        crosshair?.invalidate()
    }

    // ---- Crosshair window: full screen, never touchable ----

    private fun addCrosshair() {
        val v = CrosshairView(this, prefs)
        val lp = LayoutParams(
            LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT,
            LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_NOT_TOUCHABLE or
                LayoutParams.FLAG_LAYOUT_IN_SCREEN or LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            lp.layoutInDisplayCutoutMode = LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        crosshair = v
    }

    // ---- Floating menu: draggable bubble + collapsible panel ----

    private fun addMenu() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        bubble = TextView(this).apply {
            text = "\u2261"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCC1E88E5.toInt())
            }
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        }

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(0xEE212121.toInt())
            }
            layoutParams = LinearLayout.LayoutParams(dp(260), LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(8) }
            visibility = View.GONE
        }

        root.addView(bubble)
        root.addView(panel)

        menuParams = LayoutParams(
            LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
            LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (prefs.menuX >= 0) prefs.menuX else dp(16)
            y = if (prefs.menuY >= 0) prefs.menuY else dp(200)
        }

        buildPanel()
        installDrag()
        wm.addView(root, menuParams)
        menuRoot = root
    }

    private fun installDrag() {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragging = false

        bubble.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = menuParams.x; startY = menuParams.y
                    dragging = false
                    v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(80).start()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && hypot(dx, dy) > slop) dragging = true
                    if (dragging) {
                        menuParams.x = (startX + dx).toInt()
                        menuParams.y = (startY + dy).toInt()
                        clampAndUpdate()
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                    if (dragging) {
                        prefs.menuX = menuParams.x
                        prefs.menuY = menuParams.y
                    } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                        v.performClick()
                        togglePanel()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun clampAndUpdate() {
        val root = menuRoot ?: return
        val (sw, sh) = screenSize()
        menuParams.x = menuParams.x.coerceIn(0, max(0, sw - root.width))
        menuParams.y = menuParams.y.coerceIn(0, max(0, sh - root.height))
        runCatching { wm.updateViewLayout(root, menuParams) }
    }

    private fun togglePanel() {
        panelOpen = !panelOpen
        panel.pivotX = 0f
        panel.pivotY = 0f
        if (panelOpen) {
            panel.visibility = View.VISIBLE
            panel.alpha = 0f
            panel.scaleY = 0.9f
            panel.animate().alpha(1f).scaleY(1f).setDuration(160).start()
            panel.post { clampAndUpdate() } // keep the opened panel on screen
        } else {
            panel.animate().alpha(0f).scaleY(0.9f).setDuration(140).withEndAction {
                if (!panelOpen) panel.visibility = View.GONE
            }.start()
        }
    }

    // ---- Panel content ----

    private fun buildPanel() {
        panel.removeAllViews()

        addTitle("Crosshair")
        addSwitch("Show crosshair", prefs.crosshairOn) { prefs.crosshairOn = it; redraw() }
        addSlider("Arm length", 2, 60, prefs.size, "dp") { prefs.size = it; redraw() }
        addSlider("Thickness", 1, 8, prefs.thickness, "dp") { prefs.thickness = it; redraw() }
        addSlider("Center gap", 0, 30, prefs.gap, "dp") { prefs.gap = it; redraw() }
        addSlider("Opacity", 10, 100, prefs.opacity, "%") { prefs.opacity = it; redraw() }

        val colorBtn = Button(this)
        fun colorLabel() {
            colorBtn.text = "Color: " + Prefs.COLOR_NAMES[prefs.colorIndex.coerceIn(0, Prefs.COLORS.lastIndex)]
        }
        colorLabel()
        colorBtn.setOnClickListener {
            prefs.colorIndex = (prefs.colorIndex + 1) % Prefs.COLORS.size
            colorLabel()
            redraw()
        }
        panel.addView(colorBtn, rowParams())

        addTitle("Range ring (manual, static)")
        addSwitch("Show ring", prefs.ringOn) { prefs.ringOn = it; redraw() }
        addSlider("Radius", 5, 60, prefs.ringRadiusPct, "% of short side") {
            prefs.ringRadiusPct = it; redraw()
        }

        val reset = Button(this).apply {
            text = "Reset visuals"
            setOnClickListener { prefs.resetVisuals(); buildPanel(); redraw() }
        }
        val stop = Button(this).apply {
            text = "Stop overlay"
            setOnClickListener { stopSelf() }
        }
        panel.addView(reset, rowParams())
        panel.addView(stop, rowParams())
    }

    private fun rowParams() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun addTitle(text: String) {
        panel.addView(TextView(this).apply {
            this.text = text
            setTextColor(0xFF64B5F6.toInt())
            textSize = 14f
            setPadding(0, dp(8), 0, dp(2))
        }, rowParams())
    }

    private fun addSwitch(label: String, initial: Boolean, onChange: (Boolean) -> Unit) {
        panel.addView(Switch(this).apply {
            text = label
            setTextColor(Color.WHITE)
            isChecked = initial
            setOnCheckedChangeListener { _, checked -> onChange(checked) }
        }, rowParams())
    }

    private fun addSlider(
        label: String, min: Int, max: Int, initial: Int, unit: String, onChange: (Int) -> Unit
    ) {
        val start = initial.coerceIn(min, max)
        val title = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            text = "$label: $start $unit"
        }
        val bar = SeekBar(this).apply {
            this.max = max - min
            progress = start - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    val v = min + p
                    title.text = "$label: $v $unit"
                    if (fromUser) onChange(v)
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        panel.addView(title, rowParams())
        panel.addView(bar, rowParams())
    }
}
