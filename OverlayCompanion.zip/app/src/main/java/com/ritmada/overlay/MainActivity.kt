package com.ritmada.overlay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var grant: Button
    private lateinit var toggle: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        status = TextView(this).apply { textSize = 18f }
        val info = TextView(this).apply {
            textSize = 14f
            text = "Draws a customizable crosshair and an optional static ring over any app, " +
                "with a draggable floating menu. It does not read or modify any game."
            setPadding(0, pad / 2, 0, pad)
        }
        grant = Button(this).apply {
            text = "Grant overlay permission"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }
        toggle = Button(this).apply {
            setOnClickListener {
                val svc = Intent(this@MainActivity, OverlayService::class.java)
                if (OverlayService.running) stopService(svc) else startForegroundService(svc)
                postDelayed({ refresh() }, 400)
            }
        }
        root.addView(status)
        root.addView(info)
        root.addView(grant)
        root.addView(toggle)
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val can = Settings.canDrawOverlays(this)
        status.text = when {
            !can -> "Overlay permission not granted"
            OverlayService.running -> "Overlay is running"
            else -> "Overlay is stopped"
        }
        grant.visibility = if (can) View.GONE else View.VISIBLE
        toggle.isEnabled = can
        toggle.text = if (OverlayService.running) "Stop overlay" else "Start overlay"
    }
}
