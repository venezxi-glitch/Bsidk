# Overlay Companion

Floating menu + center-screen crosshair + static range ring. Not built or tested by the author of this file.

## Build without a PC (GitHub Actions, from the phone browser)
1. Create a free GitHub account and a new repository (branch `main`).
2. In the repo: Add file > Create new file. Type each path below with slashes to create folders,
   paste the file's contents, commit. Repeat for every file:
   settings.gradle.kts, build.gradle.kts, gradle.properties, README.md,
   app/build.gradle.kts, app/src/main/AndroidManifest.xml,
   app/src/main/java/com/ritmada/overlay/{Prefs,CrosshairView,OverlayService,MainActivity}.kt,
   .github/workflows/build.yml
3. Actions tab > "Build APK" > Run workflow (it also runs on every push to main).
4. When it finishes, open the run and download the `app-debug` artifact (a zip containing app-debug.apk).
5. Unzip on the phone, open the APK, allow "install unknown apps" for your file manager or browser.

## First run
Open Overlay Companion, grant "Display over other apps", tap Start overlay, then switch to the game.
Tap the blue bubble to open the menu; drag it to move it. Settings persist across restarts.

## Local build (if you ever have a desktop)
Gradle 8.7, JDK 17, Android SDK platform 34: `gradle assembleDebug`
